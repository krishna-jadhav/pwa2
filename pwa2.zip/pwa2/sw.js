self.addEventListener('install', function(e) {
 e.waitUntil(
   caches.open('video-store').then(function(cache) {
     return cache.addAll([
       '/',
       'index.html', 
       'fake-img.jpg', 
     ]);
   })
 );
});

self.addEventListener('fetch', function(e) {
  console.log(e.request.url);
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});

/******************* */
"serviceWorker"in navigator?window.addEventListener("load",function(){var e=document.querySelector("polytimer-app");navigator.serviceWorker.register("sw.js").then(function(t){serviceWorkerRegistration=t,getUserSubscriptionStatus(),t.onupdatefound=function(){var r=t.installing;r.onstatechange=function(){switch(r.state){case"installed":navigator.serviceWorker.controller?e.setAttribute("service-worker-state","update"):e.setAttribute("service-worker-state","installed");break;case"waiting":return e.setAttribute("service-worker-state","update");case"redundant":return e.setAttribute("service-worker-state","redundant")}}}})}):console.warn("Browser does not support service worker.");